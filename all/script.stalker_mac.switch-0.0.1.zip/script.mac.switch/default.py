# -*- coding: utf-8 -*-
#
############
# 06.06.2026
# Ctrl_Esc
############

import os, xbmc, xbmcvfs, xbmcaddon, xbmcgui
import urllib.request
import time
import random
import xml.etree.ElementTree as ET

addon_id = "plugin.video.stalker"
addon = xbmcaddon.Addon(addon_id)

addon_path = xbmcvfs.translatePath("special://home/addons/plugin.video.stalker")
addon_path_2 = xbmcvfs.translatePath("special://home/addons/script.mac.switch")
config_path = os.path.join(addon_path_2, "resources", "config")
mac_list_path = xbmcvfs.translatePath("special://home/addons/script.mac.switch/resources/mac_list.txt")
settings_path = xbmcvfs.translatePath(f"special://home/userdata/addon_data/{addon_id}/settings.xml")
resources_settings_path = os.path.join(addon_path, "resources", "settings.xml")

####

## Externe URL aus config.txt lesen

if not os.path.exists(config_path):
    with open(config_path, 'w') as f:
        f.write("\n") ###

if not xbmcvfs.exists(config_path):
    xbmcgui.Dialog().ok("Fehler", "Die Datei 'config' mit der Portals MAC-URL wurde nicht gefunden!")
    exit()

with open(config_path, "r") as f:
    base_gist_url = f.readline().strip()

if not base_gist_url.startswith("h"):  ###
    xbmcgui.Dialog().ok("Fehler", f"Ungültige config!\n{base_gist_url}")
    exit()

gist_url = f"{base_gist_url}?nocache={int(time.time())}"

## MAC-Adressen laden – zuerst extern, dann lokal
def load_mac_addresses():
    macs = []
    source = "Extern"

    try:
        req = urllib.request.Request(gist_url, headers={'Cache-Control': 'no-cache'})
        with urllib.request.urlopen(req, timeout=5) as response:
            content = response.read().decode('utf-8')
            macs = [line.strip() for line in content.splitlines() if line.strip()]
    except:
        pass

    if not macs:
        source = "Lokal"
        xbmcgui.Dialog().notification("MAC-Switch", "NO EXTERN Portal MAC-Address Found!!!     ---->>>     NOW we use the local MAC list.txt!", xbmcgui.NOTIFICATION_INFO)
        try:
            with open(mac_list_path, 'r') as f:
                macs = [line.strip() for line in f if line.strip()]
        except Exception as e:
            xbmcgui.Dialog().ok("ERROR", f"NO MAC-Address found. Check data or MAC list!\nFehler: {e}")
            return [], source

    return macs, source

## MACs laden
macs, source = load_mac_addresses()
if not macs:
    xbmcgui.Dialog().ok("MAC-Switch", "NO MAC-Address found!")
    exit()

macs.insert(0, "[[COLOR lime]--RANDOM MAC-Change--[/COLOR]]")

selected = xbmcgui.Dialog().select("MAC-Switch – Portal 1", macs)
if selected == -1:
    xbmcgui.Dialog().ok("MAC-Switch", "Nothing Changed.")
    exit()

if selected == 0:
    new_mac = random.choice(macs[1:])
else:
    new_mac = macs[selected]

## XML-Einträge aktualisieren
def update_mac_in_file(file_path):
    if not os.path.exists(file_path):
        return False
    try:
        tree = ET.parse(file_path)
        root = tree.getroot()
        updated = False
        for setting in root.findall("setting"):
            if setting.get("id") == "portal_mac_1":
                setting.set("value", new_mac)
                updated = True
        if updated:
            tree.write(file_path)
        return updated
    except:
        return False

## Kodi-Einstellung setzen für MAC portal 1
try:
    addon.setSetting("portal_mac_1", new_mac)
    kodi_set = True
except:
    kodi_set = False

active_updated = update_mac_in_file(settings_path)
resources_updated = update_mac_in_file(resources_settings_path)

msg = f"New MAC-Address: [COLOR lime]{new_mac}[/COLOR]\n"
msg += f"MAC-Source: [COLOR lime]{source}[/COLOR]"
xbmcgui.Dialog().ok("MAC-Switch – Portal 1", msg)
